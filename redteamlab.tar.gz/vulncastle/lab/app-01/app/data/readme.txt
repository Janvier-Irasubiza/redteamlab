ACME Corp Internal API
======================
This API provides access to internal resources.
For support, contact: devops@acme-corp.local

Internal credentials (DO NOT SHARE):
  Redis: admin-01.internal:6379 (no auth)
  Samba: file-01.internal (guest access enabled)
