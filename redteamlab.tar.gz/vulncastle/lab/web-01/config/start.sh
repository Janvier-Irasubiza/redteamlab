#!/bin/bash
mkdir -p /run/php
service php8.1-fpm start
service cron start
/usr/sbin/sshd
nginx -g "daemon off;"
