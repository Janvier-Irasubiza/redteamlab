#!/bin/bash
###############################################################################
# VulnCastle - Lab Startup Script (Linux / macOS / WSL)
###############################################################################
set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

echo -e "${CYAN}"
echo "╔══════════════════════════════════════════════╗"
echo "║           VulnCastle Lab Environment         ║"
echo "║   Intentionally Vulnerable - Training Only   ║"
echo "╚══════════════════════════════════════════════╝"
echo -e "${NC}"

# Check Docker
if ! command -v docker &> /dev/null; then
    echo -e "${RED}[ERROR] Docker is not installed.${NC}"
    echo "Install Docker: https://docs.docker.com/get-docker/"
    exit 1
fi

# Check Docker Compose
if ! docker compose version &> /dev/null; then
    echo -e "${RED}[ERROR] Docker Compose (v2) is not available.${NC}"
    exit 1
fi

# Check Docker daemon
if ! docker info &> /dev/null 2>&1; then
    echo -e "${RED}[ERROR] Docker daemon is not running. Please start Docker.${NC}"
    exit 1
fi

echo -e "${YELLOW}[*] Building base image...${NC}"
docker build -t vulncastle-base:latest ./lab/base/

echo -e "${YELLOW}[*] Building and starting all services...${NC}"
docker compose up -d --build

echo ""
echo -e "${GREEN}[+] VulnCastle is running!${NC}"
echo ""
echo -e "${CYAN}=== DMZ Network (attacker-accessible) ===${NC}"
echo "  Web Portal  : http://localhost:8080"
echo "  Webmail     : http://localhost:8025"
echo "  SSH Gateway : ssh -p 2222 sysadmin@localhost (pass: admin123)"
echo ""
echo -e "${CYAN}=== Internal Network (pivot required) ===${NC}"
echo "  API Server  : app-01    (10.10.0.13:3000)"
echo "  Database    : db-01     (10.10.0.14:3306)"
echo "  File Share  : file-01   (10.10.0.15:445)"
echo "  Admin Panel : admin-01  (10.10.0.16:8080)"
echo ""
echo -e "${YELLOW}[!] This environment is intentionally vulnerable.${NC}"
echo -e "${YELLOW}    DO NOT expose to untrusted networks.${NC}"
