#!/bin/bash
###############################################################################
# VulnCastle - Lab Shutdown Script (Linux / macOS / WSL)
###############################################################################
echo "[*] Stopping VulnCastle lab..."
docker compose down
echo "[+] Lab stopped."
